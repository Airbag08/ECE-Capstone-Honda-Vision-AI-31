from java.io import File
import re

VIN_RE  = re.compile(r"^[A-HJ-NPR-Z0-9]{17}$")
DATE_RE = re.compile(r"^\d{4}\.\d{2}\.\d{2}$")
TIME_RE = re.compile(r"^\d{2}\.\d{2}\.\d{2}$")

def _toFileUrl(fullPath):
    return "file:///" + fullPath.replace("\\", "/").replace(" ", "%20")

def _parseParts(base):
    # Supports both:
    # VIN_VIN_2025.03.26 07.24.06
    # VIN_VIN_2025.03.26_07.24.06

    parts = base.split("_")
    if len(parts) < 3:
        return (None, None, None)

    vin = parts[0].strip()

    # Only require that something exists for VIN
    # so shorter-than-17 VINs still appear in table.
    if not vin:
        return (None, None, None)

    if parts[1].strip().upper() != "VIN":
        return (None, None, None)

    dtPart = "_".join(parts[2:]).strip()

    if " " in dtPart:
        dateTimeParts = dtPart.split(" ")
        parseFmt = "yyyy.MM.dd HH.mm.ss"
        dtRaw = dtPart
    elif "_" in dtPart:
        dateTimeParts = dtPart.split("_")
        parseFmt = "yyyy.MM.dd_HH.mm.ss"
        dtRaw = dtPart
    else:
        return (None, None, None)

    if len(dateTimeParts) != 2:
        return (None, None, None)

    datePart = dateTimeParts[0].strip()
    timePart = dateTimeParts[1].strip()

    if not DATE_RE.match(datePart) or not TIME_RE.match(timePart):
        return (None, None, None)

    dt = system.date.parse(dtRaw, parseFmt)
    dtStr = datePart.replace(".", "-") + " " + timePart.replace(".", ":")

    return (vin, dt, dtStr)

def buildDataset(folderPath):
    rows = []

    d = File(str(folderPath))
    if (not d.exists()) or (not d.isDirectory()):
        headers = ["VIN", "Date & Time", "Flag (0)", "Image Path"]
        return system.dataset.toDataSet(headers, rows)

    allowed = [".png", ".jpg", ".jpeg", ".bmp", ".gif"]
    tmp = []
    flagCount = 0

    for child in d.listFiles():
        if not child.isFile():
            continue

        name = child.getName()
        lower = name.lower()
        if not any(lower.endswith(ext) for ext in allowed):
            continue

        base = name.rsplit(".", 1)[0]

        # auto-detect from filename
        isFlagged = base.upper().endswith("_FLAGGED")

        # strip suffix before parsing VIN/date/time
        if isFlagged:
            parseBase = base[:-8]
            flagText = "FLAGGED"
            flagCount += 1
        else:
            parseBase = base
            flagText = ""

        vin, dt, dtStr = _parseParts(parseBase)
        if vin is None:
            continue

        imgPath = _toFileUrl(child.getAbsolutePath())
        tmp.append((dt, vin, flagText, imgPath))

    # newest first
    tmp.sort(key=lambda x: x[0].getTime(), reverse=True)

    for dt, vin, flagText, imgPath in tmp:
        rows.append([vin, dt, flagText, imgPath])

    headers = ["VIN", "Date & Time", "Flag (" + str(flagCount) + ")", "Image Path"]
    return system.dataset.toDataSet(headers, rows)

def refreshTable(root, tableName="Table"):
    root.getComponent(tableName).data = buildDataset(root.annotatedFolder)